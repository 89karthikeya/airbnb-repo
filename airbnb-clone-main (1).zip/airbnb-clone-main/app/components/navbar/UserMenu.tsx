"use client";

import { AiOutlineMenu } from "react-icons/ai";
import { useCallback, useEffect, useRef, useState } from "react";
import { User } from "@prisma/client";
import { signOut } from "next-auth/react";

import Avatar from "../Avatar";
import MenuItem from "./MenuItem";

import useRegisterModal from "@/app/hooks/useRegisterModal";
import useLoginModal from "@/app/hooks/useLoginModal";
import useRentModal from "@/app/hooks/useRentModal";
import { useRouter } from "next/navigation";

interface UserMenuProps {
  currentUser?: User | null;
}

const UserMenu: React.FC<UserMenuProps> = ({ currentUser }) => {
  const registerModal = useRegisterModal();
  const loginModal = useLoginModal();
  const rentModal = useRentModal();
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  const toggleOpen = useCallback(() => setIsOpen((prev) => !prev), []);

  useEffect(() => {
    if (!isOpen) {
      return;
    }

    const closeOnOutsidePress = (event: MouseEvent) => {
      // The ref spans the trigger too, so pressing the avatar falls through to
      // `toggleOpen` instead of being closed here and reopened by the click.
      if (menuRef.current?.contains(event.target as Node)) {
        return;
      }

      setIsOpen(false);
    };

    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key !== "Escape") {
        return;
      }

      setIsOpen(false);
    };

    document.addEventListener("mousedown", closeOnOutsidePress);
    document.addEventListener("keydown", closeOnEscape);

    return () => {
      document.removeEventListener("mousedown", closeOnOutsidePress);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, [isOpen]);

  // Every entry either navigates away or opens a modal, so the menu has no
  // reason to stay behind once one is picked.
  const selectItem = useCallback((action: () => void) => {
    return () => {
      setIsOpen(false);
      action();
    };
  }, []);

  const onRent = useCallback(() => {
    if (!currentUser) {
      return loginModal.onOpen();
    }
    rentModal.onOpen();
  }, [currentUser, loginModal, rentModal]);

  return (
    <div>
      <div className="relative" ref={menuRef}>
        <div className="flex flex-row items-center gap-3">
          <div
            onClick={onRent}
            className="
              hidden
              md:block
              text-sm
              font-semibold
              py-3
              px-4
              rounded-full
              hover:bg-neutral-100
              transition
              cursor-pointer
            "
          >
            Airbnb your home
          </div>
          <div
            onClick={toggleOpen}
            className="
              p-4
              md:py-1
              md:px-2
              border-[1px]
              border-neutral-200
              flex
              flex-row
              items-center
              gap-3
              rounded-full
              cursor-pointer
              hover:shadow-md
              transition
            "
          >
            <AiOutlineMenu />
            <div className="hidden md:block">
              <Avatar src={currentUser?.image} />
            </div>
          </div>
        </div>
        {isOpen && (
          <div
            className="
            absolute
            rounded-xl
            shadow-md
            w-[40vw]
            md:w-3/4
            bg-white
            overflow-hidden
            right-0
            top-12
            text-sm
          "
          >
            <div className="flex flex-col cursor-pointer">
              {currentUser ? (
                <>
                  <MenuItem
                    onClick={selectItem(() => router.push("/trips"))}
                    label="My trips"
                  />
                  <MenuItem
                    onClick={selectItem(() => router.push("/favorites"))}
                    label="My favorites"
                  />
                  <MenuItem
                    onClick={selectItem(() => router.push("/reservations"))}
                    label="My reservations"
                  />
                  <MenuItem
                    onClick={selectItem(() => router.push("/properties"))}
                    label="My properties"
                  />
                  <MenuItem
                    onClick={selectItem(rentModal.onOpen)}
                    label="Airbnb my home"
                  />
                  <hr />
                  <MenuItem onClick={selectItem(signOut)} label="Logout" />
                </>
              ) : (
                <>
                  <MenuItem
                    onClick={selectItem(loginModal.onOpen)}
                    label="Login"
                  />
                  <MenuItem
                    onClick={selectItem(registerModal.onOpen)}
                    label="Sign up"
                  />
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserMenu;
